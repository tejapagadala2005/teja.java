package com;
import java.util.Scanner;
public class simpleif {
	public static void main(String[] arg) {
		try (Scanner Sc = new Scanner(System.in)) {
			int a=Sc.nextInt();
			if(a%2==1) {
				System.out.println("it is prime number");
				}
		}
		}
	}
