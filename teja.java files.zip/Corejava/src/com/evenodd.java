package com;

public class evenodd {
	public static void main(String[]arg) {
		for(int i=1;i<=20;i++) {
			if(i%2==0) {
				System.out.println(i);
			}
		}
	}

}
