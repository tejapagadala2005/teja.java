package com;

public class Final implements c {
	public void c() {
		System.out.println("diwakar");
	}
	public void d() {
		System.out.println("likith");
	}
	public void e() {
		System.out.println("lehith");
	}
	public void g() {
		System.out.println("teja");
	}
	public static void main(String[] args) {
		Final f= new Final();
		f.c();
		f.d();
		f.e();
		f.g();
	}
}
