package com;

public class explicttypecasting {
	public static void main(String[]arg) {
		float f=1000.100f;
		short s=(short)f;
		System.out.println(s);
	}

}
