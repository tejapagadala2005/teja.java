package com;

public class globalvariables {
	static int a=10;
	public static void main(String[] arg) {
		System.out.println(a);
	}

}
