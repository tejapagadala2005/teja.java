package com;

public class multisuperclass {
	public void car1() {
		System.out.println("BMW M1");
	}
	public static void main(String[] args) {
		multisuperclass m=new multisuperclass();
		m.car1();
		}
}
