package com;

public class array1 {
	public static void main(String[] args) {
		int[]arr=new int[10];
		arr[0]=1;
		arr[1]=3;
		arr[2]=89;
		arr[4]=70;
		arr[8]=12;
		arr[9]=15;
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);
		}
	}

}
