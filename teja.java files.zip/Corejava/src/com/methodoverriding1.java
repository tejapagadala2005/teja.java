package com;

public class methodoverriding1 {
	public void whatsappuser(){
		System.out.println("version->only single tick");
	}
}
