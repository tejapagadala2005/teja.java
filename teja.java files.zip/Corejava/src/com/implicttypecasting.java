package com;

public class implicttypecasting {
	public static void main(String[] arg) {
		Short S=100;
		int a=S;
		System.out.println(a);
	}
	

}
