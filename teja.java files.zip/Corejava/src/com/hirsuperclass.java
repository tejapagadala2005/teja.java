package com;

public class hirsuperclass {
	public void car1() {
		System.out.println("ferari");
	}
	public static void main(String[] args) {
		hirsuperclass h=new hirsuperclass();
		h.car1();
	}

}
