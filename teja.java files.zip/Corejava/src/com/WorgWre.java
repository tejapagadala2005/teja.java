package com;

public class WorgWre {
	public static int mul (int a, int b) {
		int c=a*b;
		return c;
	}
 public static void main(String[]arg) {
	int result=mul(3,6);
	System.out.println(result);
}
}
