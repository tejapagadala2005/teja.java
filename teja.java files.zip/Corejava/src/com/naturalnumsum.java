package com;

public class naturalnumsum {
	public static void main(String[]arg) {
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum=sum+i;
		}
		System.out.println(sum);
	}

}
