package com;

public class hirsub1class extends hirsuperclass {
	public void car2() {
		System.out.println("rolls roys");
	}
	public static void main(String[] args) {
		hirsub1class hs1=new hirsub1class();
		hs1.car2();
		hs1.car1();
		
	}

}
