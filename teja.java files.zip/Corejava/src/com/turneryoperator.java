package com;

public class turneryoperator {
	  static int a=10;
	  static int b=20;
	  static String result = a<b ? "yes":"no";
	  public  static void main(String[] arg) {
		  System.out.println(result);
		  }
	  }
