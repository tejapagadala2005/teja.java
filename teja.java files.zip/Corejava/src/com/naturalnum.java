package com;

public class naturalnum {
	public static void main(String[] arg) {
		for(int i=1;i<=10;i++) {
			System.out.println(i);
		}
	}

}
