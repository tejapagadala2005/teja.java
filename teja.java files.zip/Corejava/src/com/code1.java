package com;
import java.util.Scanner;
public class code1{
	public static void main(String []arg) {
		try (Scanner Sc = new Scanner(System.in)) {
			int a=Sc.nextInt();
			System.out.println(a);
		}
	}

}
