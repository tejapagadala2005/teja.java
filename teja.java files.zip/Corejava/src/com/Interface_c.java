package com;

public class Interface_c {
public Interface_c() {
	
}
}
