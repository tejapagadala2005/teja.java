package com;

public class Interface_d extends Interface_c {
	public Interface_d() {
		
	}

}
