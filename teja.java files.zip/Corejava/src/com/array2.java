package com;

public class array2 {
	public static void main(String[] args) {
		String[]arr=new String[10];
		arr[0]="apple";
		arr[1]="banana";
		arr[2]="kiwi";
		arr[4]="pine apple";
		arr[8]="mango";
		arr[9]="orange";
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);
		}
	}

}
