package com;

public interface d extends c {
	default void d_(){
		
	}

}
