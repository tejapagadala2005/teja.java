package com;

public class singlesubclass extends Singlesuperclass {
	public static void main(String[] args) {
		singlesubclass ssc=new singlesubclass();
		ssc.a=10;
		ssc.b=20;
		ssc.display();
		int c=50;
		System.out.println(c);
		int d=03;
		System.out.println(d);
	}

}
