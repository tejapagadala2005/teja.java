package com;

public class localvariables {
	public static void main(String[] arg) {
		int a=10;
	System.out.println(a);
	}

}
