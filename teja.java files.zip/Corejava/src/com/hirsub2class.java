package com;

public class hirsub2class extends hirsuperclass{
	public void car3() {
		System.out.println("benz");
	}
	public static void main(String[] args) {
		hirsub2class hs2=new hirsub2class();
		hs2.car3();
		hs2.car1();;
	}

}
