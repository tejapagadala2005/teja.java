package com;

public interface c {
  default void c_() {
	}

}
