package com;

public class Interface_e {

}
