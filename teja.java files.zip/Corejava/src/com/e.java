package com;

public interface e extends d{
	default void e_() {
		
	}

}
