package com;

public class test {
	public void sample() {
		System.out.println("sample book");
	}
	public static void main(String[] args) {
		test t=new test();
		t.sample();
	}
}
