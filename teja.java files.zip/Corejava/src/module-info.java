/**
 * 
 */
/**
 * 
 */
module Corejava {
}