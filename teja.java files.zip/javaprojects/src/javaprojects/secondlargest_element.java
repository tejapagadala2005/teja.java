package javaprojects;

public class secondlargest_element {
	public static void main(String[] args) {
		int[]arr= {1,2,3,4,5,6,10,20,99,69,52,200};
		int i;
		for ( i = 0; i < arr.length-1; i++) {
			for (int j = 0; j < arr.length-1; j++) {
				if (arr[j]>arr[j+1]) {
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
			System.out.println(arr[i-1]);
		}
	}