package javaprojects;
import java.util.Scanner;
public class ovals {
	public static void main(String[] arg) {
		Scanner Sc=new Scanner(System.in);
		char ch=Sc.next().charAt(0);
		if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U') {
			System.out.println("ch is oval");
			}
		else {System.out.println("ch is not oval");
		
		}
		}

}
